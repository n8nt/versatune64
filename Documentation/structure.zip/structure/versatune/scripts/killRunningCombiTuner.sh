#!/bin/bash
pidof CombiTunerExpress > xxx
if [ -s xxx ]; then
	echo  CombiTunerExpress is running
        killall -9 CombiTunerExpress
else
	echo  CombiTunerExpress is not running 
fi
