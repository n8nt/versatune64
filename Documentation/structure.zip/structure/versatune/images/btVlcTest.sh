cvlc  --quiet $PROG --codec ffmpeg --video-title-timeout=100 \
  --sub-filter marq --marq-size 20 --marq-x 25 --marq-position=8 --marq-file "/home/pi/overlay.txt" \
  --gain 3 --alsa-audio-device  \
/home/pi/mytest.mp4  >/dev/null 2>/dev/null &

