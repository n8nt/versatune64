#!/bin/bash -xv
#
#  example
#
#	
#   stdbuf -oL /usr/local/apps/versatune/data/CombiTunerExpress -m dvbt -f 421000 ib 2000 &
#
#
export DISPLAY=:5

mode=$1
freq=$2
bw=$3
combitunerPath=$4
fifo=$5
stdbuf -oL $combitunerPath -m $mode -f $freq -b $bw >> $fifo  &
#stdbuf -oL $combitunerPath -m $mode -f $freq -b $bw >> $fifo >/dev/null 2>/dev/null &
echo running in MODE $1 with FREQ $2 and Bandwidth $3

