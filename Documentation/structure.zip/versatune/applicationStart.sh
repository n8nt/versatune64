#!/bin/bash
sleep 10
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-arm64
export APP_DIR=/usr/local/apps/versatune
PATH=$PATH:$APP_DIR:${APP_DIR}/conf
export PATH
echo JAVA HOME IS $JAVA_HOME
echo PATH is $PATH
sudo /usr/bin/java  -Dspring.profiles.active=dev -Dspring.config.additional-location=/usr/local/apps/versatune/conf/ -jar -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005  /usr/local/apps/versatune/versatune.jar > /usr/local/apps/versatune/logs/Application.log 2>&1
echo DONE
